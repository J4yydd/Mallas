package principales;

import edlineal.Arreglo;

public class PrincipalArreglos {
    public static void main(String[] args) {

        Arreglo lista= new Arreglo(5);
        Arreglo lista2 = new Arreglo(5); 

       

        lista.poner("A");
        lista.poner("B");
        lista.poner("C");
        lista.poner("D");
         


        lista2.poner("E");
        lista2.poner("B");
        lista2.poner("C");
        lista2.poner("D");
        lista2.obtener(-1);
        System.out.println(lista.obtener(-1));
        lista2.quitar(2); 
        System.out.println(" el elemento quitado fue: "+ lista2.quitar(2));
      
       


        lista.imprimir();
        lista2.imprimir(); 
        System.out.println("----");

        lista.quitar();
        lista.imprimir();
        lista2.quitar();
        lista2.imprimir();
        lista.esIgual(lista2);




    }
}
