package principales;
import ednolineal.Arreglo3D;
import entradasalida.Salida;


public class PrincipalCubo {
    public static void main(String[] args) {
        Arreglo3D cubo = new Arreglo3D(5, 4, 3, 1); // inicializo la matriz y le doy el valor inicial de 1
        cubo.obtenerCelda(2, 3, 1);
        cubo.imprimirXColumnas();
        cubo.cambiarCelda (1, 2, 0, 90); // aqui es donde se cambia de celda con el  valor que decidimos
        cubo.imprimirXColumnas();//
        Object valorCelda = cubo.obtenerCelda(1, 2, 0);//
        Salida.salidaPorDefecto(" Valor celda: " + valorCelda);//
    }
    
}
