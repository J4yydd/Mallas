package principales;
import edlineal.Arreglo;
import edlineal.ArregloNumerico;

public class PrincipalAOrdenado {
   public static void main(String[] args) {
    /* 
       ArregloOrdenado lista = new ArregloOrdenado(6);
       ArregloOrdenado lista2 = new ArregloOrdenado(7);
       ArregloOrdenado listaPrincipal = new ArregloOrdenado(6);
       ArregloOrdenado listaSublista = new ArregloOrdenado(4);
      
       ArregloOrdenado listaActual = new ArregloOrdenado(6);
       ArregloOrdenado listaNuevosValores = new ArregloOrdenado(6);
       listaActual.poner("1");
        listaActual.poner("2");
        listaActual.poner("3");
        listaActual.poner("4");
        listaActual.poner("5");
        listaActual.poner("6");

        listaNuevosValores.poner("2");
        listaNuevosValores.poner("3");
        listaNuevosValores.poner("4");
        boolean modificar = listaActual.modificarLista(listaActual, listaNuevosValores);
       



      
    
       lista.poner("M");
       lista.poner("O");
       lista.poner("Q");
       lista.poner("V");
       lista.poner("S");
       lista.poner("A");
     //  Arreglo  reborujarLista = (Arreglo) lista.arregloDesordenado(); // creo mi objeto para desordenar usando el método para desordenar, tomando base a lista
        //Salida.salidaPorDefecto("\nLista desordenada:\n");
      // reborujarLista.imprimirDes();
       lista2.poner("M");
       lista2.poner("O");
       lista2.poner("S");
       lista2.poner("V");
       lista2.poner("Q");
       lista2.poner("A");

       listaPrincipal.poner("A");
       listaPrincipal.poner("B");
       listaPrincipal.poner("C");
       listaPrincipal.poner("D");
       listaPrincipal.poner("E");
       listaPrincipal.poner("F");

       listaSublista.poner("C");
       listaSublista.poner("D");
       listaSublista.poner("E");
       listaSublista.poner("F");


       boolean esSublista = listaPrincipal.esSublista(listaSublista);
       Salida.salidaPorDefecto("\n¿la lusta secundaria  es sublista de la lista original?: " + esSublista + "\n");

      // tomando de base el método poner, se imprimirá el arreglo de mayor valor a menor valor
      // Salida.salidaPorDefecto("Lista en orden :\n");
      // lista.imprimirDes();
      
    //  Salida.salidaPorDefecto("\nLista INC:\n"); // método que imprime el arreglo de marera incremental
        // Eliminar un elemento del arreglo
       // lista2.quitar("V");

        // Imprimir lista después de eliminar el valor que elegí
      //  Salida.salidaPorDefecto("\nLista después de eliminar 'V':\n");
       // lista2.imprimirDes();
        // método que modifica el indice con el caracater
      //boolean modificado = lista.modificar(2, "B");
       // Salida.salidaPorDefecto("\nLista después de modificar índice 2 con 'B':\n");
          // lista.imprimirDes();
          
          

     

      //Salida.salidaPorDefecto("\nBuscando 'O': " + lista.buscar("O"));
       //Salida.salidaPorDefecto("Buscando 'M': " + lista.buscar("M"));
         // Invertir la lista manualmente
        // lista.dec();
        // lista.invertir();
       
         // Imprimir la lista invertida

       // Salida.salidaPorDefecto("\nLista inversa:\n"); // invierte las posiciones del arreglo
       //  lista.imprimirDes();
       */
     
      /*   ArregloNumerico arregloOriginal = new ArregloNumerico(3);
arregloOriginal.poner(1);
arregloOriginal.poner(2);
arregloOriginal.poner(3);

ArregloNumerico escalares = new ArregloNumerico(3);
escalares.poner(1);
escalares.poner(2);
escalares.poner(3);

arregloOriginal.sumarEscalares(escalares);

arregloOriginal.imprimir(); 
       */
    ArregloNumerico arregloOriginal = new ArregloNumerico(3);
arregloOriginal.poner(1); 
arregloOriginal.poner(2);  
arregloOriginal.poner(3); 

ArregloNumerico arreglo1 = new ArregloNumerico(3);
arreglo1.poner(1);  
arreglo1.poner(2);  
arreglo1.poner(3);  

ArregloNumerico arreglo2 = new ArregloNumerico(3);
arreglo2.poner(4);  
arreglo2.poner(5); 
arreglo2.poner(6); 

Arreglo listas = new Arreglo(2);
listas.poner(arreglo1);  
listas.poner(arreglo2);  


arregloOriginal.sumarListaEstatica(listas);


arregloOriginal.imprimir();

        
   }
}