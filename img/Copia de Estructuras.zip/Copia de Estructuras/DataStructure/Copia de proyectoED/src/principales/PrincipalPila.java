package principales;

import edlineal.PilaFija;

public class PrincipalPila {
    public static void main(String[] args) {
        PilaFija pila= new PilaFija(6);

        pila.poner("A");
        pila.poner("b");
        pila.poner("c");
        pila.poner("d");
        pila.poner("e");
        pila.imprimir();
        pila.verTope();
    }
    
}
