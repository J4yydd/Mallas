package principales;

import ednolineal.Arreglo2D;


public class principal2D { 
    public static void main(String[] args) {
        Arreglo2D matriz = new Arreglo2D(2, 3); 
         matriz.cambiarValor(0, 0, 1);
         matriz.cambiarValor(0, 1, 6);
         matriz.cambiarValor(0, 2, 5);
         matriz.cambiarValor(1, 0, 4);
         matriz.cambiarValor(1, 1, 7);
         matriz.cambiarValor(1, 2, 9);
         
      
    
        
       
        
    }
    
}
