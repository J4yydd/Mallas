package principales;
import edlineal.ArregloNumerico;

public class PrincipalNumericos {
    public static void main(String[] args) {
        ArregloNumerico arreglo = new ArregloNumerico(3); // definimos  el tamanio del arreglo numerico 
        ArregloNumerico arreglo2 = new ArregloNumerico(3);

        arreglo.poner(1);   // asignamos los valores
        arreglo.poner(5);
        arreglo.poner(4);
        arreglo2.poner(1);   // asignamos los valores
        arreglo2.poner(6);
        arreglo2.poner(4);

     //   Salida.salidaPorDefecto(" Arreglo original:" +" \n");
      //  arreglo.imprimir();
      //  Salida.salidaPorDefecto(" Arreglo original 2:" +" \n");
       // arreglo2.imprimir();


      //  Number escalar = 2.0; // definimos el numero por el cual queremos mltiplicar

       // arreglo.porEscalar(escalar);
        //arreglo.sumarEscalar(escalar); // invocacion del metodo para sumar el escalar de cada posicion de el arreglo
       // Salida.salidaPorDefecto("\nArreglo después de multiplicar por el escalar..  " + escalar +" \n");
      // Salida.salidaPorDefecto("\nArreglo después de sumarle  el escalar..  " + escalar +" \n");
     // arreglo.sumar(arreglo2);
   
      //Salida.salidaPorDefecto("\nArreglos después de haberse sumado:" + "\n");
        //arreglo.imprimir(); // imprime el arrreglo ya modificado 

        //Salida.salidaPorDefecto("\nArreglos después de haberse sumado:" + "\n");
        //arreglo.multiplicar(arreglo2);
       // arreglo.imprimir();
      // Number escalar = 3.0; // definimos el numero por el cual se hara la serie de potencias
       // Salida.salidaPorDefecto("\nArreglos después de haberse sumado:" + "\n");
        //arreglo.aplicarPotencia(escalar);
       // arreglo.imprimir();
       
            // Creamos el primer arreglo con bases
            /* 
            ArregloNumerico arregloBase = new ArregloNumerico(3);
            arregloBase.poner(2);
            arregloBase.poner(3);
            arregloBase.poner(4);
        
            // Creamos el segundo arreglo con exponentes
            ArregloNumerico arregloExponencial = new ArregloNumerico(3);
            arregloExponencial.poner(3);
            arregloExponencial.poner(2);
            arregloExponencial.poner(1);

            Salida.salidaPorDefecto(" Arreglo original:" +" \n");
            arregloBase.imprimir();
            Salida.salidaPorDefecto(" Arreglo Exponencial:" +" \n");
            arregloExponencial.imprimir();
        
 
            arregloBase.aplicarPotencia(arregloExponencial);
            Salida.salidaPorDefecto(" Arreglo base modificado Exponencialmente:" +" \n");
          
            arregloBase.imprimir(); 
            */
            
    /*
    ArregloNumerico vector1 = new ArregloNumerico(3);
    vector1.poner(2);
    vector1.poner(3);
    vector1.poner(4);

   
    ArregloNumerico vector2 = new ArregloNumerico(3);
    vector2.poner(5);
    vector2.poner(6);
    vector2.poner(7);

    Salida.salidaPorDefecto(" Vector con sus valores A B C :" +" \n");
    vector1.imprimir();

    Salida.salidaPorDefecto(" Vector 2  con sus valores X Y Z :" +" \n");
    vector2.imprimir();
    Salida.salidaPorDefecto(" Producto escalar:" +" \n");

   
    double resultadoParaT = vector1.productoEscalar(vector2); // se calcula el producto escalra

    
    Salida.salidaPorDefectoNumerica(resultadoParaT); // muestro el resultado numerico T
    */
  //  ArregloNumerico vector = new ArregloNumerico(3);
   // vector.poner(3);
   // vector.poner(4);

   
    //double normaVector = vector.norma(); // se calcula la norma 

   // Salida.salidaPorDefecto("resultado de la norma del vector:" +" \n");
   // Salida.salidaPorDefectoNumerica(normaVector);
   /* 
   ArregloNumerico vector1 = new ArregloNumerico(3);
   vector1.poner(2);
   vector1.poner(6);
  ;

   ArregloNumerico vector2 = new ArregloNumerico(3);
   vector2.poner(1);
   vector2.poner(4);
 

   double resultado = vector1.normaEuclidiana(vector2);
   Salida.salidaPorDefecto("Norma Euclidiana entre vector1 y vector2: " + resultado);
 */

 ArregloNumerico arregloOriginal = new ArregloNumerico(3);
arregloOriginal.poner(1);
arregloOriginal.poner(2);
arregloOriginal.poner(3);

ArregloNumerico escalares = new ArregloNumerico(3);
escalares.poner(1);
escalares.poner(2);
escalares.poner(3);

arregloOriginal.sumarEscalares(escalares);

arregloOriginal.imprimir(); 

        }

        
      
        





        

        
    }
    

