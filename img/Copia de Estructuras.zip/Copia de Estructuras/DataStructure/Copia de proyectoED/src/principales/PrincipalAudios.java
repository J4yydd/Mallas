package principales;

import edlineal.ArregloNumerico;
import entradasalida.Salida;

public class PrincipalAudios {
    public static void main(String[] args) {
        double[] buffer2 = {12.1, 44.3, 11.3};
        ArregloNumerico ola = new ArregloNumerico(buffer2.length);
        ola.guardarDatos(buffer2);
        ola.imprimir();
        Salida.salidaPorDefecto(" hola");
    
}
 }
