package principales;

import entradasalida.Salida;
import tools.matematicas.tratamientoExpresiones;

public class principalExpresionArit {
    public static void main(String[] args) {
        //abcd/*+zn^ 
        Salida.salidaPorDefectoNumerica(tratamientoExpresiones.evaluarPostfija("2242/*+23^-"));
       
        
    }
}
