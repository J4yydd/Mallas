package tools.matematicas;

import edlineal.PilaFija;

public class tratamientoExpresiones {
    // Convertir una expresion infija a postfija
    public static String convertirInfijaaPostFija(String infija) {
        return "";
    }
    // Convertir una expresion infija a prefija

    // Evaluar una expresion infija
    public static Double evaluarInfija(String infija) {
        String postfija = convertirInfijaaPostFija(infija);
        // convertir a prefija o postfija
        // mandar llamar al de evaluar postfija o prefija
        return evaluarPostfija(postfija);
    }

    // Evaluar una expresion postfija
    public static Double evaluarPostfija(String postfija) {
        PilaFija pila = new PilaFija(postfija.length());
        // 1. tokenizar la Epos de izquierda a derecha
        for (int posToken = 0; posToken < postfija.length(); posToken++) {
            char token = postfija.charAt(posToken); // un token

            if (esOperando(token+"") == true) {

                // a) si es operando, se mete en la pila
                if (pila.poner(token+"") == false) {
                    return null;
                }

            } else { // es operador

                String op2 = (String) pila.quitar();
                String op1 = (String) pila.quitar();

                Double numero1 = Double.parseDouble(op1);
                Double numero2 = Double.parseDouble(op2);

                Double resultado = operacionAritmetica(token, numero1, numero2);

                // hay un error
                if (resultado == null) {
                    return null;
                }

                if (pila.poner(resultado+"") == false) {
                    return null;
                }


            }
            //  a) Si es operando se mete en la pila
            //  b) si es operador, se extraen dos operandos de la pila
            // el primer operando es OP2), se calcula la operacion con ese token y se mete el resultado en la pila


        }

        //  2. El resultado de la evaluacion esta en la pila
        String cadenaResultado = (String) pila.quitar();
        if (cadenaResultado == null) {
            return null;
        }

        return  Double.parseDouble(cadenaResultado);

    }

    public static Double operacionAritmetica(char operador, Double op1, double op2) {
        if (operador == '+') {
            return op1 + op2;
        } else if (operador == '-') {
            return op1 - op2;
        } else if (operador == '/') {

            if (op1 != 0) {
                return op1 / op2;
            } else {
                return  null;
            }

        } else if (operador == '*') {
            return  op1 * op2;
        } else if (operador == '^') {
            return Math.pow(op1,op2);
        } else if (operador == '%') {
            return op1 % op2;
        } else {
            // valor invalido
            return null;
        }
    }

    public static boolean esOperando(String token) {
        if (token.equals("+")) {
            return false;
        } else if (token.equals("-")) {
            return false;
        } else if (token.equals("/")) {
            return false;
        } else if (token.equals("*")) {
            return false;
        } else if (token.equals("^")) {
            return false;
        } else if (token.equals("%")) {
            return false;
        } else if (token.equals("(")) {
            return false;
        } else if (token.equals(")")) {
            return false;
        }
        // si regresa true es operando^
        return true;
    }
    // Evaluar una expresion prefija
} 
