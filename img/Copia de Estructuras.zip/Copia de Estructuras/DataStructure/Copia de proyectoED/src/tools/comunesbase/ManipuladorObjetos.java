package tools.comunesbase;


public class ManipuladorObjetos {
   
        // commpara 2 objetos y me dice, si es objeto1 mayor que objeto2
        // si objeto 1 es mayoer o igual que objeto 2.
        // si objeo  1 es menor que objeto 2

        public static int compararObjetos(Object objeto1, Object objeto2){
            if(objeto1 instanceof Number && objeto2 instanceof Number ){
                // los 2 son números, s no lo son entonces no los voy a comparar
                Double numero1 = Double.parseDouble(objeto1.toString());
                Double numero2 = Double.parseDouble(objeto2.toString());
                if(numero1 > numero2){
                    return 1; 

                }
                else if(numero1<numero2){
                    return -1; 

                }else {// igual 
                    return 0; 
                    
                }


            }else{// por lo menos uno  no es un numero
                // el metodo compareto regresa un positivo si 01 > 2
                /// si 01 es menor que 02 regresa un negativo 
                //si 01 =02 regresa 0 

            
           return objeto1.toString().compareToIgnoreCase(objeto2.toString()); 

            }


        }
    }
    

