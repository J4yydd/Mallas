package ednolineal; 

import entradasalida.Salida; 


public class Arreglo2D {
    protected int ancho; 
    protected int alto; 
    protected Object datos[][]; 

    
    public Arreglo2D(int alto, int ancho) {
        this.ancho = ancho; // tiene el numero de columnas 
        this.alto = alto;   // lo mismo pero con las filas
        datos = new Object[alto][ancho]; //es el arreglo bidimencional 
    }

    
    public Arreglo2D(int alto, int ancho, Object valor) { // el constructor que rellena con un valor inicial
        this(alto, ancho); // llama a al arreglo 2D que tiene ancho y alto. 
        rellenar(valor);  // se encarga de rellenar el arregl ocon el valor especificado con en el 3D
    }

    
    public void rellenar(Object valor) {
        for (int fila = 0; fila < alto; fila++) {          
            for (int col = 0; col < ancho; col++) {         
                datos[fila][col] = valor;                  
            }
        }
    }
    public int obtenerRenglones(){ // lo unico que se hace aqui es retornar el alto de la matriz
        return alto;
    }
    public int obtenerColumnas() { // retorna el ancho de la matriz
        return ancho;  
    }


    
    public void imprimirXRenglones() { // se encarga de imprimir la matriz por defecto
        for (int fila = 0; fila < alto; fila++) {   // recorre los renglones 
            for (int col = 0; col < ancho; col++) {      // recorre las coliumnas    
                Salida.salidaPorDefecto(datos[fila][col] + " ");  // imprime los valores de cada for. 
            }
            Salida.salidaPorDefecto("\n");                 
        }
    }
    public void imprimirXColumnas (){
        for ( int col = 0; col < ancho; col ++){
            for(int fila = 0; fila < alto; fila ++){
                Salida.salidaPorDefecto( datos[fila][col] + " ");

            }
            Salida.salidaPorDefecto(" \n");
             }
        }
    

  
    private boolean validarIndice(int tamanioDimension, int indice) {
        return indice >= 0 && indice < tamanioDimension;   
    }

  
    public Object obtenerValor(int fila, int columna) { // obtiene valores de una celda 
       
        if (validarIndice(alto, fila) && validarIndice(ancho, columna)) { // dolo ve si los indices son validos
           
            return datos[fila][columna]; // retorna el valor de la celda con datos.
          
        } else {
            return false; 
        }
    }

   
    public boolean cambiarValor(int fila, int columna, Object valor) { // se cambia el valor de un lugar 
        if (validarIndice(alto, fila) && validarIndice(ancho, columna)) { // verificador de indices unicamente
            datos[fila][columna] = valor; // se asigna el valor actualizado a la cenlda 
            return true; //todo se pudo hacer 
        } else {
            return false; //indice no es valido
        }
    }
  
    public void transpuesta() {
        Arreglo2D matrizTranspuesta = new Arreglo2D(ancho, alto); // aqui es donde sera la nueva matriz donde sera ancho y alto 
    
        for (int fila = 0; fila < alto; fila++) {
            for (int col = 0; col < ancho; col++) {
                matrizTranspuesta.cambiarValor(col, fila, datos[fila][col]); // ahora lo que recibira datos son las posiciones invertidas
            }
        }
        this.alto = matrizTranspuesta.obtenerRenglones(); // se reemplazan los datos originales con la transpuesta
        this.ancho = matrizTranspuesta.obtenerColumnas();
        this.datos = matrizTranspuesta.datos;
    }
    public Arreglo2D clonar() {
       
        Arreglo2D MatrizClon = new Arreglo2D(alto, ancho); // creo la matriz clon  
    
       
        for (int fila = 0; fila < alto; fila++) { // for para recopilar los valores de la original 
            for (int col = 0; col < ancho; col++) {
                MatrizClon.cambiarValor(fila, col, datos[fila][col]); // se copea 
            }
        }
    
        return MatrizClon; //  se deuelve el clon
    }
    public boolean esIgual(Arreglo2D matriz) {
        if (this.alto != matriz.obtenerRenglones() || this.ancho != matriz.obtenerColumnas()) {
            return false; 
        }
        for (int fila = 0; fila < alto; fila++) { // se compara posicion por posicion
            for (int col = 0; col < ancho; col++) {
                if (!datos[fila][col].equals(matriz.obtenerValor(fila, col))) {
                    return false; // en caso de que no se cumpla la condicion 
                }
            }
        }
    
        return true;
    }
    public boolean redefinir(Arreglo2D matriz2) { 
        
        this.alto = matriz2.obtenerRenglones(); // se asignan las nuevas dimenciones 
        this.ancho = matriz2.obtenerColumnas();
    
       
        this.datos = new Object[alto][ancho]; // nuevo arreglo pero con las misma propiedades
    
       
        for (int fila = 0; fila < alto; fila++) { // aqui se copean los valores de la matriz actual para pasarlos a la otra
            for (int col = 0; col < ancho; col++) {
                this.datos[fila][col] = matriz2.obtenerValor(fila, col);
            }
        }
    
        return true; 
    }
}

 