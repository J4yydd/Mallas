package ednolineal;

import entradasalida.Salida;

//hay que ver al cubo como dimensiones aisladas, como arreglo unidimensional de a mentiritas
//para cada uno de ellos voy a hacer un ciclo
public class Arreglo3D {
    protected int ancho;
    protected int alto;

    protected int profundidad;
    protected Object datos[][][]; //donde los vamos a guardar, es lo más importante
    // []filas (alto evento)[]columnas (ancho)[]profundidad
    // cada ciclo tiene un orden autónomo

    public Arreglo3D(int alto, int ancho, int profundidad){

        this.ancho = ancho;
        this.alto = alto;
        this.profundidad = profundidad;
        datos = new Object [alto][ancho][profundidad];
    }
    

    public Arreglo3D(int alto, int ancho, int profundidad, Object valor){
        this(alto, ancho, profundidad);//invocar al constructor de arriba
        //invocar al método rellenando usando valor...
        rellenar(valor);

    }

    public void rellenar(Object valor){
        //hacer mi ciclo para lo alto, filas
        for(int cadaFila = 0; cadaFila < alto; cadaFila ++){
            //hacer el ciclo de lo ancho, columnas
            for(int cadaCol = 0; cadaCol < ancho; cadaCol++){
                //hacer la profundidad,
                for(int cadaProf = 0; cadaProf < profundidad; cadaProf ++){
                    //Por cada celda [] [] []
                    datos[cadaFila][cadaCol][cadaProf] = valor; 

                }

            }

        }



    }

    public void imprimirXColumnas(){
       
        for(int cadaRebanada = 0; cadaRebanada < ancho; cadaRebanada ++){
           
            for(int cadaFila = 0; cadaFila < alto; cadaFila ++){
               
                for(int cadaColumna = 0; cadaColumna < profundidad ; cadaColumna++){
                    Salida.salidaPorDefecto(datos[cadaFila][cadaRebanada][cadaColumna]+ " ");

                }
                //Cuando se hayan impreso todas las columnas de una fila, saltamos de línea
                Salida.salidaPorDefecto("\n");
            }
            //Cuando se hayan impreso todos los renglones de una rebanada, saltamos de línea
            Salida.salidaPorDefecto("\n");
             //  en la salida por defecto 
             // en la salida por defecto,

        }
    }
    // 2 metodos, uno para leer y otro para cambiar valores 
    // en el cubo, en una celda particular
    
    
    // validar si una dimencion especifica es valoda
private boolean validarIndice(int tamanioDimension, int indiceValidar){
    if (indiceValidar >= 0 && indiceValidar < tamanioDimension){
        return true;
    }else{
        return false; 
    }

}

    // este extrar el valor de una celsa en una posicion epsecifica
    public Object obtenerCelda(int fila, int columna, int profundo){
        if(validarIndice(alto,fila)== true && validarIndice(ancho, columna) == true && validarIndice(profundidad, profundo) == true){
            // me dieron una fula una columna y una profundidad
            // valida
            // retorno el valor de esa celda
            return datos[fila][columna][profundo];

        }else{ // no hay indice valido
            return null; 

        }

    }

    // este coloca un valor a una celda 
    public boolean cambiarCelda(int fila, int columna, int profundo, Object valor){
        if(validarIndice(alto,fila)== true && validarIndice(ancho, columna) == true && validarIndice(profundidad, profundo) == true){
            // me dieron una fula una columna y una profundidad
            // valida
            // retorno el valor de esa celda
             datos[fila][columna][profundo] = valor; 
             return true;

        }else{ // no hay indice valido
            // el else es retornando
            
            return false; 

        }


        
    }
    
}
