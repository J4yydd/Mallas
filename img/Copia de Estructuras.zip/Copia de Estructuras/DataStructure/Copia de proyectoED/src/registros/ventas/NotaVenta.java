package registros.ventas;

import edlineal.Arreglo;

public class NotaVenta {

    protected int folio;
    protected String fecha;
    protected Vendedor vendedorVenta;
    protected Cliente clienteVenta;
    protected Arreglo articulosVenta;
    protected Arreglo cantidadArticulos;
    protected double total;

    public NotaVenta(int cantidadArticulosVenta, Cliente cliente, Vendedor vendedor, String fecha) {
        clienteVenta = cliente;
        vendedorVenta = vendedor;
        this.fecha = fecha;
        articulosVenta = new Arreglo(cantidadArticulosVenta);
        cantidadArticulos = new Arreglo(cantidadArticulosVenta);

        folio = 0;
        total = 0.0;

    }

    public boolean agregarArticulo(Articulo articuloVendido, int cuantos) {

        int resultadoInsercionA = articulosVenta.poner(articuloVendido);
        int resultadoInsercionC = cantidadArticulos.poner(cuantos);

        if(resultadoInsercionA == -1  || resultadoInsercionC == -1) {
            return false;
        } else {
            return true;
        }



    }

    private  double calcularTotal() {

        // recorrer arreglos paralelos, obtener articulos y sus costos, y multiplicarlos por la cantidad vendidad
        for (int pocisionArreglo = 0; pocisionArreglo <= articulosVenta.cantidad(); pocisionArreglo ++) {
        }
        return 0;
    }

}
