package edlineal;



import tools.comunesbase.ManipuladorObjetos;

public class ArregloOrdenado extends Arreglo {
    public ArregloOrdenado(int tamanio ){
        super (tamanio); 
    }
    public Object buscar(Object valor){
        int posicionB=0; 
        while(posicionB <= indiceSuperior && ManipuladorObjetos.compararObjetos(valor, datos[posicionB])>0){
            posicionB = posicionB +1; 


        }
        // primero no se encontro 
        if (posicionB>indiceSuperior || ManipuladorObjetos.compararObjetos(valor, datos[posicionB])<0){
            return (posicionB +1) * (-1); 
        }else{
            return posicionB +1; 
        }
    }

   
   
    
    public Integer poner(Object valor ){
        if(lleno()== false){ // hay espacio 
            int posicionEncontrado = (int)buscar(valor);
            if (posicionEncontrado <0){
                posicionEncontrado  = posicionEncontrado * (-1);
                posicionEncontrado = posicionEncontrado -1; 
                for (int posMod = (indiceSuperior+1); posMod >=(posicionEncontrado+1); posMod--){
                    datos[posMod]=datos [posMod -1]; 
                } 
                datos [ posicionEncontrado] = valor; 
                indiceSuperior = indiceSuperior +1; 
                return posicionEncontrado; 

                

            }else{ // si existe 
                return -1; 
            } // no existe
        
        }else{ // no hay espaci
            return -1; 

        }
    }
    // Método para invertir el arreglo
public  void invertir() {
    int puntoDepartida = 0;
    int finArreglo = indiceSuperior;
    while (puntoDepartida < finArreglo) {
        Object invert = datos[puntoDepartida];
        datos[puntoDepartida] = datos[finArreglo];
        datos[finArreglo] = invert;
        puntoDepartida++;
        finArreglo--;
    }
}
    

    public boolean modificar(int indice, Object valor) { // el método recibe la posición y el valor
     
        
        // se elimina primero el valor que tiene la posicion correspondiente 
        Object eliminarPos = datos[indice];
        
        for (int recorredorP = indice; recorredorP < indiceSuperior; recorredorP++) { // se inicia el for asignandole la variable a indice
            datos[recorredorP] = datos[recorredorP + 1];
        }
        indiceSuperior--; // Reducimos el índice superior mientras se este ejecutando el for
     // Insertar el nuevo valor en la posición correcta
        return poner(valor) >= 0; // Retorna true si se insertó correctamente, false si no hay espacio
    }


     public Object quitar(Object valor) {
        int posicion = (int) buscar(valor);
        
        if (posicion >= 0) { // verifico si el elemento existe en el arreglo, para a partir de ahi poder mover los elementos
            Object eliminado = datos[posicion];
            
            for (int desplazaM = posicion; desplazaM < indiceSuperior; desplazaM++) { // desplazo los elementos para llenar el vacio 
                datos[desplazaM] = datos[desplazaM + 1];
            }
            datos[indiceSuperior] = null;
            indiceSuperior--;  // < --- aqui decremento el indice superior indicando que se removió con exito
            return eliminado;
        }
        
        return null; // en caso que no se encuentre nada
    }
    @Override
  public ListaDatos arregloDesordenado() {
    Arreglo desordenado = new Arreglo(this.capacidad()); // Crear un nuevo arreglo con la misma capacidad

   
    for (int controlC = 0; controlC <= this.indiceSuperior; controlC++) { // copeo los elementos actuales de lista, para ponerlos en el nuevo arreglo desordenado
        desordenado.poner(this.datos[controlC]);
    }

    for (int controlV = 0; controlV < desordenado.cantidad(); controlV++) { // plasmamos los elementos obtenidos para intercambiarlos de forma secuencial 
        // defino una variable como estanque para poder crear mi secuencia 
        int intercambioPos = (controlV + 1) % desordenado.cantidad(); 
        // Intercambiar los elementos en las posiciones controlV y intercambioPos
        Object changeA = desordenado.datos[controlV];
        desordenado.datos[controlV] = desordenado.datos[intercambioPos];
        desordenado.datos[intercambioPos] = changeA;
    }

    return desordenado;
}

public boolean esSublista(ListaDatos lista2){
    if ((lista2 instanceof ArregloOrdenado) == false) {
        return false;

    }
    ArregloOrdenado listaNuevaOrdenada = (ArregloOrdenado) lista2; 
    int recorredorA = 0;
    int recorredorB =0;  

    while (recorredorA < this.cantidad() && recorredorB < listaNuevaOrdenada.cantidad()) {
        // Si el elemento de la lista actual coincide con el elemento de lista2
        if (this.datos[recorredorA].equals(listaNuevaOrdenada.datos[recorredorB])) {
            recorredorB++; // recorrsmos posicion a la lista2
        }
        recorredorA++;  // recorremos posicion a la actual 
    }
    
    // si a pasado la prueba, entonces es una sublista perfec
    return recorredorB == listaNuevaOrdenada.cantidad();
}

public boolean modificarLista(ListaDatos lista2, ListaDatos lista2Nuevos) {
    
    if (!(lista2 instanceof ArregloOrdenado) || !(lista2Nuevos instanceof ArregloOrdenado)) {
        return false; 
    }

    // convierto las listas a ArregloOrdenado para poder acceder a los datos
    ArregloOrdenado listaVieja = (ArregloOrdenado) lista2;
    ArregloOrdenado listaNueva = (ArregloOrdenado) lista2Nuevos;

    // Comprobamos que las listas tengan la misma cantidad de elementos
   /*  if (listaVieja.cantidad() != listaNueva.cantidad()) {
        return false; // Si las listas no tienen la misma cantidad de elementos, no se pueden modificar
    }

    // Recorremos ambas listas para buscar los elementos a reemplazar
    for (int actual = 0; actual < listaVieja.cantidad(); actual++) {
        for (int original = 0; original < listaNueva.cantidad(); original++) {
                                              // si encontramos un valor en listaVieja que coincida con el de listaNueva
            if (listaVieja.datos[actual].equals(listaNueva.datos[original])) {
                listaVieja.datos[actual] = listaNueva.datos[original]; // el valor se reemplazaen  el valor en listaVieja
            }
        }
    }
    */
    return true; 
}
 }
