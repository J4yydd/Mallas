package edlineal;

import entradasalida.Salida;

public class ArregloNumerico extends Arreglo {

    public ArregloNumerico(int tamanio) {
        super(tamanio); // Llamamos al constructor de la clase base
    }

    @Override
    public Integer poner(Object Valor) {
        if (Valor instanceof Number) { // Validamos si el valor es una instancia de Number
            return super.poner(((Number) Valor).doubleValue()); // Convertimos a double y usamos el método de la clase base
        } else {
            Salida.salidaPorDefecto("El valor que me proporcionaste no cumple con las condiciones.");
            return -1; // Indicamos error si el valor no es numérico
        }
    }

    @Override
    public Object buscar(Object Valor) {
        if (Valor instanceof Number) { // Validamos si el valor es numérico
            return super.buscar(Valor); // Llamamos al método de la clase base
        } else {
            Salida.salidaPorDefecto("Error: El valor debe ser numérico.");
            return -1; // Indicamos error si el valor no es numérico
        }
    }

  
    

    @Override
    public void imprimirDes() {
        for (int i = indiceSuperior; i >= 0; i--) {
            if (datos[i] instanceof Number) { // Solo imprimimos si el valor es numérico
                Salida.salidaPorDefecto(datos[i] + "\n");
            }
        }
    }

    @Override
    public Object quitar(Object Valor) {
        if (Valor instanceof Number) { // Validamos si el valor es numérico
            return super.quitar(Valor); // Llamamos al método de la clase base
        } else {
            Salida.salidaPorDefecto("Error: El valor debe ser numérico.");
            return null; // Indicamos error si el valor no es numérico
        }
    }

    @Override
    public boolean esIgual(ListaDatos lista2) {
        if (lista2 instanceof ArregloNumerico) { // Verificamos que la lista sea de tipo ArregloNumerico
            return super.esIgual(lista2); // Llamamos al método de la clase base
        } else {
            Salida.salidaPorDefecto("Error: Los arreglos no son del tipo ArregloNumerico.");
            return false;
        }
    }

    @Override
    public Object obtener(int indice) {
        Object valor = super.obtener(indice);
        if (valor instanceof Number) { // Validamos si el valor es numérico
            return valor; // Retornamos el valor si es numérico
        } else {
            return null; //si no es numérico, retornamos null
        }
    }
    public boolean porEscalar(Number escalar){
        if (indiceSuperior == -1) { // primer filtro solamente verificando que el arreglo esta vacio o no.
            return false;
        }
    
       
        for (int locationA = 0; locationA <= indiceSuperior; locationA++) {// muyltiplico cada posicion del arreglo por el numero escalar
            if (datos[locationA] instanceof Number) { // utiulizo instanceof para verificar que el valor sea numerico 
                
                datos[locationA] = ((Number) datos[locationA]).doubleValue() * escalar.doubleValue(); // convertimos el valor a double y multiplicamos por el escalar 
            }
        }
        return true; // si todo esta bien, un true ;)
    }
    public boolean sumarEscalar(Number escalar) { // metodo para poder sumar el escalar de cada posicion del arreglo
        if (indiceSuperior == -1) { 
            return false;
        }
    
       for (int locationA = 0; locationA <= indiceSuperior; locationA++) {
            if (datos[locationA] instanceof Number) { 
                datos[locationA] = ((Number) datos[locationA]).doubleValue() + escalar.doubleValue();
            }
        }
        return true;
    }
    public boolean sumar(ArregloNumerico lista2) {
       if (this.cantidad() != lista2.cantidad()) { // aqui lo unico que hago es verificar si ambos arreglos tienen la misma cantidad de valores
            return false; // si no, retorno un false para no proceguir con el método
        }
    
        //sumar los valores de las posiciones correspondientes de ambos arreglos
        for (int multiValor = 0; multiValor <= this.indiceSuperior; multiValor++) { // hago el for para recorrer las posiciones de ambos arreglos
            if (this.datos[multiValor] instanceof Number && lista2.datos[multiValor] instanceof Number) { // comfirmamos el valor numerico de cada arrelglo
                //convertimos ambos valores a Double y los sumamos
                this.datos[multiValor] = ((Number) this.datos[multiValor]).doubleValue() + ((Number) lista2.datos[multiValor]).doubleValue(); // comvertimos los valores a double y pot ultimo los sumamos
            }
        }
    
        return true; // todo bien
    }
    public boolean multiplicar(ArregloNumerico lista2) {
        if (indiceSuperior == -1 || this.cantidad() != lista2.cantidad()) {  
            return false;  
        }
    
        for (int incideMultiplicador = 0; incideMultiplicador <= indiceSuperior; incideMultiplicador++) {
            if (this.datos[incideMultiplicador] instanceof Number && lista2.datos[incideMultiplicador] instanceof Number) {
                this.datos[incideMultiplicador] = ((Number) this.datos[incideMultiplicador]).doubleValue() * ((Number) lista2.datos[incideMultiplicador]).doubleValue();
            }
        }
        return true;
    }
    public boolean aplicarPotencia(Number escalar) {
        if (indiceSuperior == -1) {
            return false;
        }
    
        for (int recorredorArreglo = 0; recorredorArreglo <= indiceSuperior; recorredorArreglo++) {
            if (datos[recorredorArreglo] instanceof Number) { // filtro de valores numericos
                double arregloPotenciado = ((Number) datos[recorredorArreglo]).doubleValue(); // como en todos los métodos, lo convierto a double
                int exponente = escalar.intValue(); // lo convierto a entero para poder usarlo de base para el exponente
                double resultadoPote = 1; // lo inicializo en 1 y no en cero para poder comenzar a acenderlo en el for 
    
          
                for (int posicionMultiplicarVeces = 0; posicionMultiplicarVeces < exponente; posicionMultiplicarVeces++) { // hago el ciclo for para poder multiplicar la potencia dependiendo de el numero dado
                    resultadoPote *= arregloPotenciado;
                }
    
                datos[recorredorArreglo] = resultadoPote; // nada mas lo guardamos en la misma posicion
            }
        }
        return true;
    }
    public boolean aplicarPotencia(ArregloNumerico listaEscalares) {
        if (indiceSuperior == -1) { 
            return false;
        }
        
        if (this.indiceSuperior != listaEscalares.indiceSuperior) {
            return false; 
        }
      for (int recEscalar = 0;  recEscalar  <= this.indiceSuperior;  recEscalar ++) { // ciclo para recorrer el arreglo
           
            if (this.datos[recEscalar] instanceof Number && listaEscalares.datos[recEscalar] instanceof Number) { // simplemenrte verificacion como en los metodos anteriores
                double arrBase = ((Number) this.datos[recEscalar]).doubleValue(); 
                int arrexponente = ((Number) listaEscalares.datos[ recEscalar ]).intValue(); // Convertimos el exponente a int
                double resultado = 1;
    
           
                for (int multiplicadorP = 0; multiplicadorP < arrexponente; multiplicadorP++) { //igual el mismo for para calcular la potencia.
                    resultado *= arrBase;
                }
               this.datos[ recEscalar] = resultado; // se coloca el resultado en la base 
            }
        }
        return true;
    }

    public double productoEscalar(ArregloNumerico lista2) {
        
        if (this.indiceSuperior != lista2.indiceSuperior) {
            return 0.0; // si no tienen el mismo numero de valores, no se puede ejecutar el metodio
        }
    
        double suma = 0.0; // almacenaré el resultado en esta variable 
    
      
        for (int elementosArreglo = 0; elementosArreglo <= this.indiceSuperior; elementosArreglo++) { /// ciclo para recorrer los elementos del arreglo
          
            if (this.datos[elementosArreglo] instanceof Number && lista2.datos[elementosArreglo] instanceof Number) { // verficamos que sean numeros como entodos los métodoos
                //multiplico los valores en la misma posición y sumamos al resultado total
                suma += ((Number) this.datos[elementosArreglo]).doubleValue() * ((Number) lista2.datos[elementosArreglo]).doubleValue();
            }
        }
        
        return suma; // retornamos el producto escalar
    }
    public double norma() {
        double sumaCuadrados = 0.0; 
    
       
        if (indiceSuperior == -1) {
            return 0.0;
        }
    
        //ciclo para calcular la suma de los valores
        for (int recorredorSuma = 0; recorredorSuma <= indiceSuperior; recorredorSuma++) {
            if (datos[recorredorSuma] instanceof Number) { // verificacion numerica como en todos los metodos
                double valor = ((Number) datos[recorredorSuma]).doubleValue();
                sumaCuadrados += valor * valor; // hago los cuadrados
            }
        }
    
        
        double raiz = sumaCuadrados;
        double mejorAprox;
    
        while (true) { // inicio un bucle infinito como quien dice, ya que se repetira hasta que la aproximacion sea caaasi exacta 
            mejorAprox = (raiz + sumaCuadrados / raiz) / 2; // Fórmula de Newton
    
            // comparo si la diferencia entre estas es poca
            double diferencia = raiz - mejorAprox; // saco diferencia
            if (diferencia < 0) { // condiciono para que la diferencia sea positica y no negativa 
                diferencia = -diferencia;
            }
    
            if (diferencia < 0.0000000000000000000000000000000000000000000000000000000000000000000000000000000001) { // tolerancia de exactud, por eso puse ceros a lo menso, y asi el while se repita hasta llegar al limite de aqui establecido 
                break;
            }
    
            raiz = mejorAprox; // se actualiza la raiz

        }
    
        return raiz;
    }



    public double normaEuclidiana(ArregloNumerico arreglo2) {
        if (indiceSuperior == -1) {
            return 0.0;
        }
     
        double sumaCuadrados = 0;
    
        // recorremos los 2 elementos de ambos arreglos
        for (int recorredorArreglos = 0; recorredorArreglos < this.indiceSuperior; recorredorArreglos++) {
            if (this.datos[recorredorArreglos] instanceof Number && arreglo2.datos[recorredorArreglos] instanceof Number) {
                // obtenemos valores numericos
                double valor1 = ((Number) this.datos[recorredorArreglos]).doubleValue();
                double valor2 = ((Number) arreglo2.datos[recorredorArreglos]).doubleValue();
    
                // calculamos diferencias nada mas 
                double diferencia = valor1 - valor2;
                sumaCuadrados += diferencia * diferencia;
            }
        }
    
    
        double raiz = sumaCuadrados;
        double mejorAprox;
    
        while (true) {
            mejorAprox = (raiz + sumaCuadrados / raiz) / 2;
    
            double diferencia = raiz - mejorAprox;
            if (diferencia <= 0) {
                diferencia = -diferencia;
              
            }
    
            if (diferencia < 0.00000000000000000000000000001) {
                break;
            }
    
            raiz = mejorAprox;
        }
    
        return raiz;
    }

    public void sumarEscalares(ArregloNumerico escalares) {
        if (escalares != null && this.cantidad() == escalares.cantidad()) { // verificp que ambos arreglos tengan la misma cantidad de elementos
            for (int sumarP = 0; sumarP < this.cantidad(); sumarP++) {
                Number valorEscalar = (Number) escalares.obtener(sumarP);  // obtrngo el valor escalar de las posiciones del indice sumaP
                Number valorActual = (Number) this.obtener(sumarP);  // obtengo el valor actual en la misma posicion del arreglo original
    
                if (valorEscalar != null && valorActual != null) {
                    //uma el valor escalar al valor actual
                    double nuevoValor = valorActual.doubleValue() + valorEscalar.doubleValue();
                    this.datos[sumarP] = nuevoValor;  //actualiza el valor del arreglo original con el nuevo valor
                }
            }
        } else {
            Salida.salidaPorDefecto(" los valores en los arreglos no son iguales");
          
        }
    }
    public void sumarListaEstatica(Arreglo listas) {
  
        if (listas != null && listas.cantidad() > 0) {
        
            for (int fullArrreglos = 0; fullArrreglos < listas.cantidad(); fullArrreglos++) {// recorredor de los elementos de la lista 
             
                ArregloNumerico arregloListas = (ArregloNumerico) listas.obtener(fullArrreglos); // se obtiene el valaor numerico de la posicion estatica
                
             
                if (arregloListas != null && this.cantidad() == arregloListas.cantidad()) {// verificador de compatibilidad numerica unicamente
                   
                    for (int valoresPosicion = 0; valoresPosicion < this.cantidad(); valoresPosicion++) { // se recorre todos loe elementos del arreglo
                
                        Number valorListas = (Number) arregloListas.obtener(valoresPosicion); // se obtiene el valor de la posicion de cada arreglo de listas y el actual 
                        Number valorActual = (Number) this.obtener(valoresPosicion);
                        
                  
                   if (valorListas != null && valorActual != null) {
                          
                            double nuevoValor = valorActual.doubleValue() + valorListas.doubleValue(); // se suman los valores ya con valor numerico
                            
                          
                            this.datos[valoresPosicion] = nuevoValor; // se actualizan los valores actuales
                        }
                    }
                } else {
                  
                    Salida.salidaPorDefecto("Los arreglos no tienen la misma cantidad de elementos o son nulos.");
                   
                }
            }
        } else {
          
            Salida.salidaPorDefecto("La lista de arreglos es nula o vacía.");
        }
        
        
    }
    @Override
    public void guardarDatos(double[] buffer2){
        super.guardarDatos(buffer2);
    }







    
}



   
    

    
    


