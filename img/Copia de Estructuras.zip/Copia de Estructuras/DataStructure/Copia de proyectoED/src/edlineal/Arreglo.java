package edlineal;

import entradasalida.Salida;


public class Arreglo implements VectorFijo {

    protected int capacidad;
    protected  Object datos[];
    protected  int indiceSuperior;

    public Arreglo(int tamanio) {

        this.capacidad = tamanio;
        this.datos = new Object[capacidad];
        this.indiceSuperior = -1;
    }
    

    public boolean vaciar() {

        if(indiceSuperior == -1) {
            return true;
        } else {
            return false;
        }
    }

    public boolean lleno() {
        if (indiceSuperior == (capacidad - 1)) {
            return true;
        } else {
            return false;
        }
    }

    public Integer poner(Object Valor) {
        if (lleno() == false) {
            indiceSuperior ++;
            datos[indiceSuperior] = Valor;
             return indiceSuperior;
        } else {
            return -1;
        }
    }

    @Override
    public Object buscar(Object Valor) {
        int recorredor = 0;
        while (recorredor <= indiceSuperior && Valor.toString().equalsIgnoreCase(datos[recorredor].toString()) == false) {
            recorredor ++;
        }
        if (recorredor > indiceSuperior) {
            return  -1;
        } else {
            return recorredor;
        }
    }
    @Override
    public ListaDatos arregloDesordenado(){
        return null; 
    }

    @Override
    public void imprimir() {
        int posicion;
        for(posicion = 0; posicion <= indiceSuperior; posicion ++) {
            Salida.salidaPorDefecto(datos[posicion] +"\n");
        }
    }

    @Override
    public void imprimirDes() {
        int posicion;
        for(posicion = indiceSuperior; posicion >= 0; posicion --) {
            Salida.salidaPorDefecto(datos[posicion] +"\n");
        }
    }

    public Object quitar() {
        Object datoExtraido;

        if (vaciar() == false) {
            datoExtraido = datos[indiceSuperior];
            indiceSuperior --;
            return datoExtraido;
        } else {
            return  null;
        }
    }

    @Override
    public Object quitar(Object Valor) {
        Object respaldo;
        int posicion = (int)buscar(Valor);
        int modificacion;

        if (posicion >= 0) {

            respaldo = datos[posicion];
            for(modificacion = posicion;(modificacion <= indiceSuperior -1); modificacion --) {
                datos[modificacion] = datos[modificacion + 1];
            }
            indiceSuperior --;
            return respaldo;
        } else {
            return  null;
        }


    }

    public int capacidad() {
        return capacidad;
    }

    public int cantidad() {
        return indiceSuperior+1;
    }

    private boolean validaPocision(int indice) {
        if(indice >= 0 && indice <= indiceSuperior) {
            return  true;
        } else {
            return false;
        }
    }

    // método obtiene un objeto de el arreglo indicado por la pocision de el indice

    public Object obtener(int indice) {
        if (validaPocision(indice) == true ) {
            // existe la pocision
            return datos[indice];
        } else {
            return null;
        }
    }
   @Override
   public boolean esIgual(ListaDatos lista2){ // creacion del metodo para ver si los arreglos son iguales
     if(!(lista2 instanceof Arreglo)){  // creamos una condicion donde verificamos si lista2 es instancia del arreglo
        return false; 
     }
     Arreglo arraysito = (Arreglo)lista2; // creamos el nuevo objeto de tipo arreglo
     if(this.cantidad()!= arraysito.cantidad()){ // verificamos que ambos arreglos tengan la misma cantidad de elementos
        System.out.println(" los arreglos no tienen la misma cantidad de datos");
        return false; 
     }
     for(int indiceContador = 0; indiceContador <= this.indiceSuperior; indiceContador++){ 
        Object arrayActual = this.datos[indiceContador];   // accedemos al metodo de datos
        Object arrayB = arraysito.datos[indiceContador]; 
        if(!arrayActual.equals(arrayB)){// ver ifica qeu tenga el mismo dato en la misma posicion, para saber si son iguales o no
            System.out.println(" no contienen los mismos datos en la posicion = "+ indiceContador + ".");
            return false; 
        }
        
     }
     System.out.println(" son iguales"); // si se cumple con todas las condiciones, retorna true indicando que los arreglos son iguales. 
        return true; 

   }
   public Object verFinal(){
    if(vaciar()==false){
        return datos [indiceSuperior];


    }else{
        return null; 
        
    }
   }











   public void guardarDatos(double[] buffer2) {
    if(buffer2.length>=capacidad){
        for(int recorredorBuffer = 0; recorredorBuffer< buffer2.length; recorredorBuffer++){
            datos[recorredorBuffer] = buffer2[recorredorBuffer];
        }
    }else{
        Salida.salidaPorDefecto(" no se cargo ");
    }
    indiceSuperior = buffer2.length - 1;
} 

}

   
      
 








    

        
    
 
            
     

