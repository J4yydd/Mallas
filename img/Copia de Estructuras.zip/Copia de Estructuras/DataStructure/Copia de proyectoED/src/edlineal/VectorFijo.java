package edlineal;
// esta interface maneja metodos particulares de memoria estatica
public interface VectorFijo extends ListaDatos {

    public boolean lleno();
    public int capacidad();
    public int cantidad();
    public Object obtener(int indice);
   
}
