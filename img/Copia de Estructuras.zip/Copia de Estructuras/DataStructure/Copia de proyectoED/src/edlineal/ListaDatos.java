package edlineal;
// esta inferface maneja metodos de memoria estatica y dinamica
public interface ListaDatos {

    public boolean vaciar();
    public Integer poner(Object Valor);
    public Object buscar(Object Valor);
    public void imprimir();
    public void imprimirDes();
    public Object quitar();
    public Object quitar(Object Valor);
    public boolean esIgual(ListaDatos lista2); // impplementacion del nuevo metodo.
   
    public ListaDatos arregloDesordenado(); 
    public Object verFinal(); 
    
    
}
